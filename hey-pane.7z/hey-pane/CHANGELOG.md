## 1.2.0
* Adds option to enable follow mode on startup
* Adds option in which panes follow mode will engange

## 1.1.2
* Changes default keybindings for windows and linux

## 1.1.1
* Adds default keybindings for windows and linux

## 1.1.0
* Adds a configurable delay for follow mode (See Issue #13)

## 1.0.0

* Use API from Atom 1.17, therefore stopping support for 1.16
* Switching to stable versioning

## 0.3.1
* Now compatible with Nuclide

## 0.3.0
* Adapted the API improvements of the last weeks
* Compatible with Atom 1.17

## 0.2.2
* Fixed an error when starting Atom in the new Beta 1.16.0-beta0

## 0.2.1
* Adds a message for incompatibility with Nuclide.

## 0.2.0
* Added configuration for focused panel size

## 0.1.0 - Hey, First Release!
* Every feature added
