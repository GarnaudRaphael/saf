## perspective-ui


![](https://cloud.githubusercontent.com/assets/8536244/18359430/7cc0667c-762c-11e6-954d-a6bedd998c3e.png)


Syntax theme: [ficus-dark-syntax](https://atom.io/themes/ficus-dark-syntax)


Forked from: [nattatorn-dev/min-ui-colorful](https://github.com/nattatorn-dev/min-ui-colorful)
