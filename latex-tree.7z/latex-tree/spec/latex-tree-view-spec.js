'use babel';

import LatexTreeView from '../lib/latex-tree-view';

describe('LatexTreeView', () => {
  it('has one valid test', () => {
    expect('life').toBe('easy');
  });
});
