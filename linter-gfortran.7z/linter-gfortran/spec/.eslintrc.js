module.exports = {
  env: {
    atomtest: true,
    jasmine: true
  }
};
