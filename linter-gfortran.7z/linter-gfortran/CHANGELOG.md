## 0.6.0 - 2019:02:07
* Bump minimum Atom version (#17)
* Support Linter v2 API (#23)

## 0.5.0 - 2017:05:02
* Try to fix linting under windows (#15)

## 0.4.1 - 2017:04:12
* Reduce activation time (#13)

## 0.4.0 - 2017:03:16
* Properly declare the member functions (#8)

## 0.3.0 - 2017:02:08
* Users gfortran flags (#3)
* Parse multiple errors (#3)
* Lint on-the-fly (#3)
* Improve handling of "include"

## 0.2.2 - 2016:07:18
* Fixes for Windows operating system (#2)

## 0.2.1 - 2016:02:19
* Support all Fortran grammars

## 0.2.0 - 2016:02:19
* Re-wrote the code from linter-clang
* Now handle modules files (`.mod`)

## 0.1.0 - 2016:02:15
Undocumented
