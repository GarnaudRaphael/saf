# Linter-gfortran

A linter plugin for [Linter](https://github.com/AtomLinter/Linter), using
`gfortran` to lint fortran code. This works with gfortran 5.

## License/Contribution

Code is licensed under MIT, and contributions are very welcome!
