## 0.3.1

- Fix inverse scrolling not working
- Fix modifier keys not working

## 0.3.0

- Add an option to specify a modifier key (thanks @mallardduck)
- Fix an issue where disabling "auto-toggle" would work (thanks @mallardduck)

## 0.2.0

- allow any scroll direction (thanks @mgiuffrida)

## 0.1.2 - Make direction an option

## 0.1.0 - First Release

- Every feature added
- Every bug fixed
