## 0.3.0
* Added: Support for interactive tty sessions
* Added: Copy/paste support
* Updated: xterm.js to v2.5.0 (should be faster/stronger/better etc)
* Updated: `output-panel` api to v1.0.0

## 0.2.0
* Improved: Now uses Atom 1.17 docks
* #### 0.2.1
	* Fixed: Printing text would reveal the panel again even if it had been deliberately hidden
		* If hidden the panel will now *remain* hidden when printing text. It will only reappear if the panel has been fully closed

## 0.1.0
* Initial release
