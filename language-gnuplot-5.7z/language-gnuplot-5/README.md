# GnuPlot syntax highlighting for Atom
Atom package: [https://atom.io/packages/language-gnuplot-5](https://atom.io/packages/language-gnuplot-5)

## Notice
This is a fork of [language-gnuplot-atom](https://github.com/jinhuang/language-gnuplot-atom).

The aim of this package is to provide up-to-date support for GnuPlot Syntax in Atom.


## Status

I just merged some old PRs from [language-gnuplot-atom](https://github.com/jinhuang/language-gnuplot-atom). I am looking forward to refine the syntax highlighting. Furter PRs are welcome!
