## 1.2.6

* Do not execute "run" command automatically

## 1.2.5

* Show runtime value of variable using "mouse over" (2sec delay)

## 1.2.4

* Compatibility with Atom 1.19

## 1.2.3

* Show Debug GUI after initialization process

## 1.2.2

* Improve a debugger startup time

## 1.2.1

* Show debugging console on error

## 1.2.0

* Remember project breakpoints
* Allow to terminate debug session if remote target has been disconnected
* Improve terminating of GDB and its children

## 1.1.1

* Destroy debugger on back-end error

## 1.1.0

* Switch to The PlatformIO Unified Debugger
* Highlight current debug line
* Add red breakpoint marker
* Don’t interrupt GDB if process has died
* Fix GDB start for remote targets

## 1.0.0

* Provide API for PlatformIO IDE
* Refactor UI
* Add support for GDB 7.6
