'use babel';

describe('when package is activated', () => {
  // @TODO
});
