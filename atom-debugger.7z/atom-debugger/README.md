# atom-debugger package

This is a debugger for atom.io, which now only support `gdb`.

This package is still in very early stage. In fact, I'm not sure whether there are people using atom.io to debug.

Please feel free to create issues if you have any problem or good ideas, thank you!

Before debugging, please add your source root directory into the tree-view.

![screenshot](https://raw.githubusercontent.com/xndcn/atom-debugger/master/screenshot.png?raw=true)


## TO DO

* Add `watch` view to display variable value.
